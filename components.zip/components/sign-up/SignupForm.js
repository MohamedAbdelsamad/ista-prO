import { View, Text } from "react-native";
import React from "react";
const SignupForm = () => {
  return <Text>Hello</Text>;
};

export default SignupForm;
