import { View, Text } from "react-native";
import React from "react";

const CommentSection = () => {
  return (
    <Text style={{ color: "gray", marginLeft: 15, marginTop: 5 }}>
      View {"all"} {"2"} {"comment"}
    </Text>
  );
};

export default CommentSection;
